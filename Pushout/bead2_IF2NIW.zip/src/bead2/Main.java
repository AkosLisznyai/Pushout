package bead2;

/**
 *
 * @author Lisznyai Ákos
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PushGUI game = new PushGUI();
    }
    
}
